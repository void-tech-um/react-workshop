import React from "react";
import Market from "./components/Market";

function App() {
  return (
    <>
      <Market />
    </>
  );
}

export default App;
